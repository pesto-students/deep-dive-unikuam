import React from 'react';

function DashBoard() {
  return (
      <h1>Welcome To DashBoard!!</h1>
  );
}

export default DashBoard;
